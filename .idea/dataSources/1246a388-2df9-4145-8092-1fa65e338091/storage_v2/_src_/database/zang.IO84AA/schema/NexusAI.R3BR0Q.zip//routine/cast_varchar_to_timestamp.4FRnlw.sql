create function cast_varchar_to_timestamp(character varying) returns timestamp with time zone
    strict
    language sql
as
$$
select to_timestamp($1, 'yyyy-mm-dd hh24:mi:ss');
$$;

alter function cast_varchar_to_timestamp(varchar) owner to zang;

